"use client"

import Image from "next/image"
import { Sparkles, MapPin } from "lucide-react"

const gems = [
  {
    id: 1,
    image: "/images/coxs-bazar.jpg",
    name: "Inani Beach",
    location: "Cox's Bazar",
    description: "A pristine, less-crowded stretch of beach with turquoise waters and golden cliffs.",
  },
  {
    id: 2,
    image: "/images/sajek-valley.jpg",
    name: "Khagrachari Tribal Village",
    location: "Rangamati",
    description: "Experience authentic tribal culture and homestay with indigenous communities.",
  },
  {
    id: 3,
    image: "/images/sylhet-tea.jpg",
    name: "Ratargul Swamp Forest",
    location: "Sylhet",
    description: "Serene kayaking through ancient swamp forests and limestone caves.",
  },
  {
    id: 4,
    image: "/images/rangamati.jpg",
    name: "Pablakhali Wildlife Sanctuary",
    location: "Rangamati",
    description: "Trek through pristine forests to hidden waterfalls and wildlife zones.",
  },
  {
    id: 5,
    image: "/images/sundarbans.jpg",
    name: "Sunamganj Haor",
    location: "Sunamganj",
    description: "Vast wetlands with migratory birds and tranquil village life off the beaten path.",
  },
  {
    id: 6,
    image: "/images/food-biryani.jpg",
    name: "Panam City Ghost Town",
    location: "Narayanganj",
    description: "Abandoned Victorian-era city with haunting architecture and rich history.",
  },
]

export default function HiddenGems() {
  return (
    <section className="py-20 bg-[oklch(0.15_0.04_240)]">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[oklch(0.72_0.14_75/0.15)] border border-[oklch(0.72_0.14_75/0.3)] mb-4">
            <Sparkles className="w-3.5 h-3.5 text-[oklch(0.72_0.14_75)]" />
            <span className="text-[oklch(0.72_0.14_75)] text-xs font-semibold tracking-widest uppercase">
              Secret Spots
            </span>
          </div>
          <h2 className="font-sans font-bold text-3xl md:text-4xl text-white text-balance mb-2">
            Discover Hidden <span className="text-[oklch(0.72_0.14_75)]">Gems</span>
          </h2>
          <p className="text-white/50 text-sm md:text-base font-body max-w-2xl">
            Off-the-beaten-path destinations that will make your journey unforgettable
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {gems.map((gem) => (
            <div
              key={gem.id}
              className="group relative overflow-hidden rounded-2xl h-72 cursor-pointer"
            >
              {/* Image */}
              <Image
                src={gem.image}
                alt={gem.name}
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-700"
              />

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.15_0.04_240/0.9)] via-[oklch(0.15_0.04_240/0.3)] to-transparent" />

              {/* Badge */}
              <div className="absolute top-4 right-4 inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[oklch(0.72_0.14_75)] text-white font-bold text-xs uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <Sparkles className="w-3 h-3" />
                Secret Spot
              </div>

              {/* Content - Bottom */}
              <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-8 group-hover:translate-y-0 transition-transform duration-500">
                <h3 className="font-sans font-bold text-white text-lg mb-2">{gem.name}</h3>
                <div className="flex items-center gap-1 mb-3">
                  <MapPin className="w-4 h-4 text-[oklch(0.52_0.17_155)]" />
                  <span className="text-[oklch(0.52_0.17_155)] text-sm font-medium">{gem.location}</span>
                </div>
                <p className="text-white/80 text-sm font-body leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-700">
                  {gem.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
