"use client"

import Image from "next/image"
import { Star, Clock, MapPin, ChevronRight, Compass } from "lucide-react"

const topPlaces = [
  {
    image: "/images/coxs-bazar.jpg",
    name: "Cox's Bazar",
    division: "Chittagong",
    desc: "The world's longest natural sea beach stretching 120 km of unbroken golden sands along the Bay of Bengal.",
    rating: 4.9,
    duration: "2–4 days",
    type: "Beach",
    highlight: "World's Longest Beach",
  },
  {
    image: "/images/sajek-valley.jpg",
    name: "Sajek Valley",
    division: "Rangamati",
    desc: "Perched at 1,800 ft, Sajek offers dramatic cloud-kissed hills and stunning sunrises in the Chittagong Hill Tracts.",
    rating: 4.8,
    duration: "1–2 days",
    type: "Hill Station",
    highlight: "Cloud Kingdom",
  },
  {
    image: "/images/sylhet-tea.jpg",
    name: "Sylhet Tea Gardens",
    division: "Sylhet",
    desc: "Rolling emerald tea estates, Ratargul swamp forest, and the Bisnakandi stone river create an ethereal landscape.",
    rating: 4.7,
    duration: "2–3 days",
    type: "Nature",
    highlight: "Tea Paradise",
  },
  {
    image: "/images/sundarbans.jpg",
    name: "Sundarbans",
    division: "Khulna",
    desc: "The world's largest mangrove forest and home to the Royal Bengal Tiger — a UNESCO World Heritage Site.",
    rating: 4.8,
    duration: "3–5 days",
    type: "Wildlife",
    highlight: "Tiger Reserve",
  },
  {
    image: "/images/rangamati.jpg",
    name: "Rangamati Lake",
    division: "Chittagong",
    desc: "A picturesque artificial lake surrounded by lush green hills, tribal villages, and the iconic hanging bridge.",
    rating: 4.6,
    duration: "1–2 days",
    type: "Lake",
    highlight: "Emerald Lake",
  },
]

const typeColors: Record<string, string> = {
  Beach: "text-blue-300 bg-blue-400/15 border-blue-400/30",
  "Hill Station": "text-[oklch(0.62_0.17_155)] bg-[oklch(0.52_0.17_155/0.15)] border-[oklch(0.52_0.17_155/0.3)]",
  Nature: "text-[oklch(0.72_0.14_75)] bg-[oklch(0.72_0.14_75/0.1)] border-[oklch(0.72_0.14_75/0.3)]",
  Wildlife: "text-orange-300 bg-orange-400/15 border-orange-400/30",
  Lake: "text-cyan-300 bg-cyan-400/15 border-cyan-400/30",
}

export default function TopPlaces() {
  return (
    <section className="py-20 bg-[oklch(0.15_0.04_240)]">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[oklch(0.52_0.17_155/0.15)] border border-[oklch(0.52_0.17_155/0.3)] mb-4">
              <Compass className="w-3.5 h-3.5 text-[oklch(0.52_0.17_155)]" />
              <span className="text-[oklch(0.52_0.17_155)] text-xs font-semibold tracking-widest uppercase">Top Destinations</span>
            </div>
            <h2 className="font-sans font-bold text-3xl md:text-4xl text-white text-balance">
              Must-Visit <span className="text-[oklch(0.72_0.14_75)]">Places in Bangladesh</span>
            </h2>
          </div>
          <button className="flex items-center gap-2 text-[oklch(0.52_0.17_155)] text-sm font-semibold hover:text-[oklch(0.72_0.14_75)] transition-colors duration-300 group">
            Explore All Destinations
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform duration-300" />
          </button>
        </div>

        {/* Horizontal scroll on mobile, grid on desktop */}
        <div className="flex gap-5 overflow-x-auto pb-4 md:grid md:grid-cols-3 lg:grid-cols-5 md:overflow-visible scroll-smooth snap-x snap-mandatory">
          {topPlaces.map((place) => (
            <div
              key={place.name}
              className="group flex-none w-72 md:w-auto snap-start bg-white/5 border border-white/10 rounded-2xl overflow-hidden hover:border-[oklch(0.52_0.17_155/0.4)] transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-[oklch(0.52_0.17_155/0.15)] cursor-pointer"
            >
              {/* Image */}
              <div className="relative h-44 overflow-hidden">
                <Image
                  src={place.image}
                  alt={place.name}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.15_0.04_240/0.7)] via-transparent" />
                <span className={`absolute top-3 left-3 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border backdrop-blur-sm ${typeColors[place.type] ?? "text-white/80 bg-white/10 border-white/20"}`}>
                  {place.type}
                </span>
                <div className="absolute bottom-2 left-3 right-3">
                  <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[oklch(0.72_0.14_75/0.2)] border border-[oklch(0.72_0.14_75/0.4)]">
                    <span className="text-[oklch(0.72_0.14_75)] text-[10px] font-bold">{place.highlight}</span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-sans font-bold text-white text-base">{place.name}</h3>
                    <div className="flex items-center gap-1 mt-0.5">
                      <MapPin className="w-2.5 h-2.5 text-[oklch(0.52_0.17_155)]" />
                      <span className="text-[oklch(0.52_0.17_155)] text-xs">{place.division}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 bg-[oklch(0.72_0.14_75/0.1)] px-2 py-1 rounded-lg">
                    <Star className="w-3 h-3 text-[oklch(0.72_0.14_75)] fill-[oklch(0.72_0.14_75)]" />
                    <span className="text-white text-xs font-bold">{place.rating}</span>
                  </div>
                </div>
                <p className="text-white/50 text-xs font-body leading-relaxed mb-3 line-clamp-2">{place.desc}</p>
                <div className="flex items-center gap-1 text-white/40 text-xs">
                  <Clock className="w-3 h-3" />
                  <span>{place.duration}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
