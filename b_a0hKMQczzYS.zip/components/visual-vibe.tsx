"use client"

import Image from "next/image"
import { Camera, Heart, Share2 } from "lucide-react"
import { useState } from "react"

const galleryItems = [
  { src: "/images/coxs-bazar.jpg", title: "Cox's Bazar", tag: "Beach", span: "col-span-2 row-span-2" },
  { src: "/images/sajek-valley.jpg", title: "Sajek Valley", tag: "Hills", span: "" },
  { src: "/images/sundarbans.jpg", title: "Sundarbans", tag: "Forest", span: "" },
  { src: "/images/sylhet-tea.jpg", title: "Sylhet Tea Gardens", tag: "Nature", span: "" },
  { src: "/images/rangamati.jpg", title: "Rangamati Lake", tag: "Lake", span: "" },
]

const tagColors: Record<string, string> = {
  Beach: "bg-blue-400/20 text-blue-300 border-blue-400/30",
  Hills: "bg-[oklch(0.52_0.17_155/0.2)] text-[oklch(0.62_0.17_155)] border-[oklch(0.52_0.17_155/0.3)]",
  Forest: "bg-[oklch(0.32_0.1_152/0.2)] text-[oklch(0.52_0.17_155)] border-[oklch(0.32_0.1_152/0.3)]",
  Nature: "bg-[oklch(0.72_0.14_75/0.15)] text-[oklch(0.72_0.14_75)] border-[oklch(0.72_0.14_75/0.3)]",
  Lake: "bg-cyan-400/15 text-cyan-300 border-cyan-400/30",
}

function GalleryCard({ src, title, tag, span }: typeof galleryItems[number]) {
  const [liked, setLiked] = useState(false)

  return (
    <div className={`group relative rounded-2xl overflow-hidden cursor-pointer ${span}`}>
      <Image
        src={src}
        alt={title}
        fill
        className="object-cover group-hover:scale-110 transition-transform duration-700"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.12_0.02_220/0.85)] via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

      {/* Tag */}
      <span className={`absolute top-3 left-3 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border backdrop-blur-sm ${tagColors[tag] ?? "bg-white/10 text-white border-white/20"}`}>
        {tag}
      </span>

      {/* Actions */}
      <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
        <button
          onClick={() => setLiked(!liked)}
          className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/30 transition-colors duration-200"
        >
          <Heart className={`w-4 h-4 transition-colors duration-200 ${liked ? "text-red-400 fill-red-400" : "text-white"}`} />
        </button>
        <button className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/30 transition-colors duration-200">
          <Share2 className="w-4 h-4 text-white" />
        </button>
      </div>

      {/* Title overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
        <p className="text-white font-sans font-semibold text-sm">{title}</p>
      </div>
    </div>
  )
}

export default function VisualVibe() {
  return (
    <section className="py-20 bg-[oklch(0.13_0.03_240)]">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[oklch(0.52_0.17_155/0.1)] border border-[oklch(0.52_0.17_155/0.3)] mb-4">
            <Camera className="w-3.5 h-3.5 text-[oklch(0.52_0.17_155)]" />
            <span className="text-[oklch(0.52_0.17_155)] text-xs font-semibold tracking-widest uppercase">Visual Vibe</span>
          </div>
          <h2 className="font-sans font-bold text-3xl md:text-4xl text-white text-balance mb-3">
            Destination <span className="text-[oklch(0.72_0.14_75)]">Highlights</span>
          </h2>
          <p className="text-white/50 font-body text-sm max-w-xl mx-auto text-pretty leading-relaxed">
            Stunning imagery from Bangladesh&apos;s most breathtaking destinations, curated by our AI travel engine.
          </p>
        </div>

        {/* Masonry-style Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 auto-rows-[220px] gap-4">
          {galleryItems.map((item) => (
            <GalleryCard key={item.title} {...item} />
          ))}
        </div>
      </div>
    </section>
  )
}
