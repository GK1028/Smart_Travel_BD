export interface FamousFood {
  name: string
  nameBangla: string
  description: string
  image: string
}

export const districtFoods: Record<string, FamousFood[]> = {
  "Dhaka": [
    { name: "Haji Biriyani", nameBangla: "হাজী বিরিয়ানী", description: "Legendary mutton biryani from Old Dhaka, slow-cooked with aromatic spices", image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400" },
    { name: "Bakarkhani", nameBangla: "বাকরখানি", description: "Traditional crispy flatbread, perfect with tea or curry", image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400" },
  ],
  "Chittagong": [
    { name: "Mezban Beef", nameBangla: "মেজবানের গরুর মাংস", description: "Traditional Chittagonian beef curry served at community feasts", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400" },
    { name: "Shutki Bhorta", nameBangla: "শুঁটকি ভর্তা", description: "Spicy dried fish mash, a Chittagong specialty", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
  ],
  "Chattogram": [
    { name: "Mezban Beef", nameBangla: "মেজবানের গরুর মাংস", description: "Traditional Chittagonian beef curry served at community feasts", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400" },
    { name: "Shutki Bhorta", nameBangla: "শুঁটকি ভর্তা", description: "Spicy dried fish mash, a Chittagong specialty", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
  ],
  "Cox's Bazar": [
    { name: "Fresh Seafood", nameBangla: "তাজা সামুদ্রিক মাছ", description: "Grilled lobster, crab, and fresh catch from the Bay of Bengal", image: "https://images.unsplash.com/photo-1559737558-2f5a35f4523b?w=400" },
    { name: "Shutki", nameBangla: "শুঁটকি", description: "Sun-dried fish, a local delicacy with intense flavors", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
  ],
  "Sylhet": [
    { name: "Satkora Beef", nameBangla: "সাতকরা গোশত", description: "Aromatic beef curry with wild citrus fruit unique to Sylhet", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400" },
    { name: "Pitha", nameBangla: "পিঠা", description: "Traditional rice cakes, especially famous during winter", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400" },
  ],
  "Comilla": [
    { name: "Roshmalai", nameBangla: "রসমালাই", description: "World-famous creamy milk dessert, Comilla's pride", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400" },
    { name: "Khir", nameBangla: "ক্ষীর", description: "Rich rice pudding made with fresh milk", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400" },
  ],
  "Rajshahi": [
    { name: "Mango", nameBangla: "আম", description: "World-renowned Fazli, Langra, and Himsagar mangoes", image: "https://images.unsplash.com/photo-1553279768-865429fa0078?w=400" },
    { name: "Kalai Ruti", nameBangla: "কলাই রুটি", description: "Traditional flatbread made from black gram", image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400" },
  ],
  "Khulna": [
    { name: "Galda Chingri", nameBangla: "গলদা চিংড়ি", description: "Giant freshwater prawns from the Sundarbans region", image: "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?w=400" },
    { name: "Sundarbans Honey", nameBangla: "সুন্দরবনের মধু", description: "Pure wild honey collected from the mangrove forest", image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400" },
  ],
  "Bagerhat": [
    { name: "Galda Chingri", nameBangla: "গলদা চিংড়ি", description: "Giant freshwater prawns from the Sundarbans region", image: "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?w=400" },
    { name: "Ilish Bhapa", nameBangla: "ইলিশ ভাপা", description: "Steamed hilsa fish with mustard paste", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
  ],
  "Rangamati": [
    { name: "Bamboo Chicken", nameBangla: "বাঁশের মুরগি", description: "Tribal delicacy - chicken cooked inside bamboo", image: "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=400" },
    { name: "Nappi", nameBangla: "নাপ্পি", description: "Fermented fish paste used in tribal cuisine", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400" },
  ],
  "Bandarban": [
    { name: "Bamboo Chicken", nameBangla: "বাঁশের মুরগি", description: "Tribal delicacy - chicken cooked inside bamboo", image: "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=400" },
    { name: "Traditional Rice Wine", nameBangla: "পাহাড়ি মদ", description: "Local rice-based beverage of the hill tribes", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400" },
  ],
  "Barishal": [
    { name: "Ilish Paturi", nameBangla: "ইলিশ পাতুরি", description: "Hilsa fish wrapped in banana leaf with spices", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
    { name: "Coconut Sweets", nameBangla: "নারিকেলের মিষ্টি", description: "Traditional coconut-based desserts", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400" },
  ],
  "Barisal": [
    { name: "Ilish Paturi", nameBangla: "ইলিশ পাতুরি", description: "Hilsa fish wrapped in banana leaf with spices", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
    { name: "Coconut Sweets", nameBangla: "নারিকেলের মিষ্টি", description: "Traditional coconut-based desserts", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400" },
  ],
  "Rangpur": [
    { name: "Shidal Shutki", nameBangla: "শিদল শুঁটকি", description: "Fermented dried fish, a northern delicacy", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
    { name: "Alu Bhorta", nameBangla: "আলু ভর্তা", description: "Mashed potato with mustard oil and spices", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400" },
  ],
  "Bogra": [
    { name: "Bogra Doi", nameBangla: "বগুড়ার দই", description: "Famous creamy yogurt, a must-try delicacy", image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400" },
    { name: "Chamcham", nameBangla: "চমচম", description: "Sweet milk-based dessert coated in coconut", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400" },
  ],
  "Mymensingh": [
    { name: "Monda Mithoi", nameBangla: "মন্ডা মিঠাই", description: "Traditional sweet made from reduced milk", image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400" },
    { name: "Ilish Bhuna", nameBangla: "ইলিশ ভুনা", description: "Dry-fried hilsa fish with aromatic spices", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
  ],
  "Dinajpur": [
    { name: "Lichi", nameBangla: "লিচু", description: "Famous Dinajpur litchi, sweetest in Bangladesh", image: "https://images.unsplash.com/photo-1558818498-28c1e002b655?w=400" },
    { name: "Kataribhog Rice", nameBangla: "কাটারিভোগ চাল", description: "Aromatic rice variety unique to Dinajpur", image: "https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400" },
  ],
  "Moulvibazar": [
    { name: "Seven Layer Tea", nameBangla: "সাত রং চা", description: "Unique layered tea with different flavors in each layer", image: "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?w=400" },
    { name: "Paan", nameBangla: "পান", description: "Premium betel leaf from tea garden region", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400" },
  ],
}

// Default food for districts not in the list
export const defaultFood: FamousFood[] = [
  { name: "Hilsa Fish Curry", nameBangla: "ইলিশ মাছের তরকারি", description: "Bangladesh's national fish cooked in traditional style", image: "https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400" },
  { name: "Biryani", nameBangla: "বিরিয়ানী", description: "Aromatic rice dish with tender meat and spices", image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400" },
]

export function getFamousFoods(district: string): FamousFood[] {
  return districtFoods[district] || defaultFood
}
